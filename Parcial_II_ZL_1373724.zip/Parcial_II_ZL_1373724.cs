﻿using System;
using System.Collections;
using System.ComponentModel.Design;
using System.Security.Cryptography.X509Certificates;

namespace ParcialII
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] nombres = new string[10];
            int[] notas = new int[10];

            Console.WriteLine("Ingrese los nombres de los estudiantes: ");

            for (int i = 0; i < nombres.Length; i++)
            {
                nombres[i] = Console.ReadLine();
            }

            Console.WriteLine("-------------------Nombres de los alumnos--------------------");
            for (int i = 0; i < nombres.Length; i++)
            {
                Console.WriteLine(nombres[i]);
            }

            Console.WriteLine("Ingrese las notas de cada alumno");

            for(int i = 0; i < notas.Length; i++)
            {
                notas[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("-------------------Notas de los alumnos--------------------");

            for (int i = 0; i < notas.Length; i++)
            {
                Console.WriteLine(notas[i]);
            }

            for (int i = 0; i < nombres.Length; i++)
            {
                if (notas[i] < 65)
                {
                    Console.WriteLine("El alumno " +nombres[i]+ " no ha aprovado");
                }
                else
                {
                    Console.WriteLine("El alumno " + nombres [i] + "tiene una nota satisfactoria");
                } break;
              
            }
            
        }
    }
}
