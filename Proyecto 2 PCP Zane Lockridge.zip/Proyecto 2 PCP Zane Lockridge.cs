﻿using Proyecto_PCP_Zane_Lockridge_EnFi;
using System;
using System.Security.Cryptography.X509Certificates;
using System.Transactions;
using TransferenciasCuentas;

namespace Proyecto1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Ingreso de variables

            Console.WriteLine("Ingresa tu Usuario");
            string usuario = Console.ReadLine();

            Console.WriteLine("Ingresa tu Contraseña");
            string contraseña = Console.ReadLine();

            Console.WriteLine("Ingresa tu número de teléfono");
            string telefono = Console.ReadLine();

            Console.WriteLine("Ingresa tu correo electrónico");
            string correo = Console.ReadLine();

            string DPI;
            do
            {
                Console.WriteLine("Ingresa los primeros 5 dígitos de tu DPI");
                DPI = Console.ReadLine();

            } while (!ValidacionDPI(DPI));

            Console.WriteLine("Ingresa tu saldo inicial");
            string saldoI = Console.ReadLine();

            Console.WriteLine("Ingrese el tipo de moneda");
            string moneda = Console.ReadLine();

            Console.WriteLine("Ingrese el tipo de cuenta");
            string Tcuenta = Console.ReadLine();

            Console.WriteLine("Ingrese su nombre completo");
            string nombre = Console.ReadLine();

            // Muestra toda la información de la cuenta

            Console.WriteLine("");
            Console.WriteLine("Su nombre es: " + nombre);
            Console.WriteLine("Su DPI es: " + DPI);
            Console.WriteLine("Su usuario es: " + usuario);
            Console.WriteLine("Su contraseña es: " + contraseña);
            Console.WriteLine("Su número de teléfono es: " + telefono);
            Console.WriteLine("Su correo electrónico es: " + correo);
            Console.WriteLine("Su tipo de cuenta es: " + Tcuenta);
            Console.WriteLine("Su tipo de moneda es: " + moneda);
            Console.WriteLine("Su saldo inicial es: " + saldoI);

            Console.ReadKey();
        }

        static bool ValidacionDPI(string input)
        {
            if (input.Length == 5 && int.TryParse(input, out _))
            {
                return true;
            }
            else
            {
                Console.WriteLine("Debes ingresar solamente los primeros 5 dígitos de tu DPI");
                return false;
            }

            //Venta de un producto financiero//
            //Saldo inicial (Q)//

            Console.WriteLine("");
            Console.WriteLine("Venta de un producto financiero");

            int sinicial = 2500;

            Console.WriteLine("");
            Console.WriteLine("Su saldo inicial es: " + sinicial);

            if (sinicial > 500)
            {
                //Calculos de la ganancia derivada de la transacción//

                int porcentaje = (int)(sinicial * 0.11);
                int ganancia = (int)(sinicial + porcentaje);

                Console.WriteLine("");
                Console.WriteLine("Su ganancia es de: " + porcentaje);
                Console.WriteLine("Su saldo total es de: " + ganancia);

            }
            else
            {
                //Calculos del porcentaje del saldo actual//

                int psaldo = (int)((500 - sinicial) / (sinicial / 100) * 100);

                Console.WriteLine("");
                Console.WriteLine("No es factible realizar la transaccion en este momento");
                Console.WriteLine("No es recomendable hacer la transaccion debido al porcentaje de del saldo actual. El porcentaje del Saldo actual es: " + psaldo);
            }

            //Compra de un producto financiero//

            Console.WriteLine("");
            Console.WriteLine("Compra de un producto financiero");

            Console.WriteLine("");
            Console.WriteLine("Su saldo inicial es de: " + sinicial);

            // Calculos de las perdidas y del saldo actualizado despues de la compra//

            int psaldoc = (int)(sinicial * 0.10);
            int perdida = (int)(sinicial - psaldoc);


            Console.WriteLine("");
            Console.WriteLine("Su perdida es de: " + psaldoc);
            Console.WriteLine("Su saldo actualizado es de: " + perdida);

            //Abonar la cuenta//

            int saldo = 0;
            int abonosRealizados = 0;

            Console.WriteLine("");
            Console.WriteLine("Bienvenido al sistema de abono a cuenta corriente.");

            while (abonosRealizados < 2)
            {
                Console.WriteLine("");
                Console.WriteLine("Saldo actual: " + saldo);
                if (saldo < 500)
                {
                    Console.WriteLine("");
                    Console.WriteLine("Puede realizar un abono a la cuenta.");
                    Console.Write("Ingrese el monto a abonar (máximo 2500): ");
                    int monto = Convert.ToInt32(Console.ReadLine());
                    if (monto <= 2500 && monto > 0)
                    {
                        saldo += monto;
                        abonosRealizados++;
                        Console.WriteLine("Abono realizado correctamente. Saldo actual: " + saldo);
                    }
                    else
                    {
                        Console.WriteLine("Monto no válido. Por favor ingrese un monto entre 1 y 2500.");
                    }
                }
                else
                {
                    Console.WriteLine("El saldo actual es suficiente. No es necesario abonar.");
                    break;
                }
            }

            Console.WriteLine("Ya ha alcanzado el límite de abonos permitidos este mes.");
            Console.WriteLine("Presione cualquier tecla para salir.");
            Console.ReadKey();

            Console.WriteLine("Bienvenido al Simulador Bancario");
            Console.WriteLine("Ingrese el saldo inicial: ");
            double saldoInicial = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Ingrese la tasa de interés en porcentaje (por ejemplo, 2 para 2%): ");
            double tasaInteres = Convert.ToDouble(Console.ReadLine()) / 100;
            Console.WriteLine("Seleccione el período de capitalización: ");
            Console.WriteLine("1. Mensual");
            Console.WriteLine("2. Bimensual");
            int periodoCapitalizacion = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese la cantidad de meses a simular: ");
            int mesesASimular = Convert.ToInt32(Console.ReadLine());

            int mesesTranscurridos = 0;

            double saldoo = saldoInicial;

            while (mesesTranscurridos < mesesASimular)
            {
                if (mesesTranscurridos > 0 && mesesTranscurridos % periodoCapitalizacion == 0)
                {
                    Console.WriteLine($"Saldo al final del mes {mesesTranscurridos}: {saldo:C}");
                }

                mesesTranscurridos++;

                double interes = saldo * tasaInteres;

                saldoo += interes;

                Console.WriteLine("Para cerrar el programa presione cualquier tecla.");
            }
        }
    }
}
    


    
