﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        CuentaBancaria cuenta = new CuentaBancaria();
        cuenta.IngresarInformacion();

        while (true)
        {
            Console.WriteLine("\nMenu de opciones:");
            Console.WriteLine("1. Mostrar Información");
            Console.WriteLine("2. Comprar Producto Financiero");
            Console.WriteLine("3. Vender Producto Financiero");
            Console.WriteLine("4. Abonar a Cuenta");
            Console.WriteLine("5. Simular Paso del Tiempo");
            Console.WriteLine("6. Mantenimiento de Cuentas de Terceros");
            Console.WriteLine("7. Realizar Transferencias a Otras Cuentas");
            Console.WriteLine("8. Pago de Servicios");
            Console.WriteLine("9. Imprimir Informe de Transacciones");
            Console.WriteLine("10. Salir");
            Console.Write("Seleccione una opción: ");
            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    cuenta.MostrarInformacion();
                    break;
                case "2":
                    cuenta.ComprarProductoFinanciero();
                    break;
                case "3":
                    cuenta.VenderProductoFinanciero();
                    break;
                case "4":
                    cuenta.AbonarCuenta();
                    break;
                case "5":
                    cuenta.SimularPasoDelTiempo();
                    break;
                case "6":
                    cuenta.MantenimientoCuentasTercero();
                    break;
                case "7":
                    cuenta.RealizarTransferencia();
                    break;
                case "8":
                    cuenta.PagoDeServicios();
                    break;
                case "9":
                    cuenta.ImprimirInformeTransacciones();
                    break;
                case "10":
                    return;
                default:
                    Console.WriteLine("Opción no válida.");
                    break;
            }
        }
    }
}

class CuentaBancaria
{
    public string Usuario { get; set; }
    public string Contraseña { get; set; }
    public string Telefono { get; set; }
    public string Correo { get; set; }
    public string DPI { get; set; }
    public decimal SaldoInicial { get; set; }
    public string TipoCuenta { get; set; }
    public string Nombre { get; set; }

    private int abonosRealizados = 0;
    private List<Transaccion> transacciones = new List<Transaccion>();
    private List<CuentaTercero> cuentasTercero = new List<CuentaTercero>();
    private int contadorCuentasTercero = 1;

    public void IngresarInformacion()
    {
        Usuario = SolicitarDato("Ingresa tu Usuario");
        Contraseña = SolicitarDato("Ingresa tu Contraseña");
        Telefono = SolicitarDatoConLongitud("Ingresa tu número de teléfono (8 caracteres)", 8);
        Correo = SolicitarDato("Ingresa tu correo electrónico");
        DPI = SolicitarDatoConLongitud("Ingresa tu número de DPI (5 caracteres)", 5);
        SaldoInicial = SolicitarDecimal("Ingresa tu saldo inicial");
        TipoCuenta = SolicitarTipoCuenta();
        Nombre = SolicitarDato("Ingrese su nombre completo");
    }

    public void MostrarInformacion()
    {
        Console.WriteLine("\nInformación de la cuenta:");
        Console.WriteLine($"Nombre: {Nombre}");
        Console.WriteLine($"DPI: {DPI}");
        Console.WriteLine($"Usuario: {Usuario}");
        Console.WriteLine($"Contraseña: {Contraseña}");
        Console.WriteLine($"Teléfono: {Telefono}");
        Console.WriteLine($"Correo: {Correo}");
        Console.WriteLine($"Tipo de Cuenta: {TipoCuenta}");
        Console.WriteLine($"Saldo Inicial: {SaldoInicial}");
    }

    public void RegistrarTransaccion(decimal monto, string tipo)
    {
        transacciones.Add(new Transaccion
        {
            Fecha = DateTime.Now,
            Monto = monto,
            Tipo = tipo
        });
    }

    public void ComprarProductoFinanciero()
    {
        decimal monto = SaldoInicial * 0.10m;
        SaldoInicial *= 0.90m;
        RegistrarTransaccion(monto, "Debito");
        Console.WriteLine($"Compra de producto financiero realizada exitosamente. Su saldo actual es: {SaldoInicial}");
    }

    public void VenderProductoFinanciero()
    {
        if (SaldoInicial > 500.00m)
        {
            decimal monto = SaldoInicial * 0.11m;
            SaldoInicial *= 1.11m;
            RegistrarTransaccion(monto, "Credito");
            Console.WriteLine($"Venta de producto financiero realizada exitosamente. Su saldo actual es: {SaldoInicial}");
        }
        else
        {
            Console.WriteLine("No es posible realizar la transacción. El saldo es insuficiente.");
        }
    }

    public void AbonarCuenta()
    {
        if (abonosRealizados < 2 && SaldoInicial > 500.00m)
        {
            decimal monto = SaldoInicial;
            SaldoInicial *= 2;
            abonosRealizados++;
            RegistrarTransaccion(monto, "Credito");
            Console.WriteLine($"Abono realizado. Saldo actual: {SaldoInicial}");
        }
        else if (SaldoInicial <= 500.00m)
        {
            Console.WriteLine("No es posible realizar el abono. El saldo es insuficiente.");
        }
        else
        {
            Console.WriteLine("No es posible realizar el abono. Ya ha realizado el máximo de abonos permitidos este mes.");
        }
    }

    public void SimularPasoDelTiempo()
    {
        int periodoCapitalizacion;
        do
        {
            Console.WriteLine("Ingrese el período de capitalización (1 para una vez al mes, 2 para dos veces al mes):");
        } while (!int.TryParse(Console.ReadLine(), out periodoCapitalizacion) || (periodoCapitalizacion != 1 && periodoCapitalizacion != 2));

        int diasPorPeriodo = periodoCapitalizacion == 1 ? 30 : 15;
        int totalPeriodos = 12 * periodoCapitalizacion;

        for (int i = 0; i < totalPeriodos; i++)
        {
            decimal interes = SaldoInicial * 0.02m * diasPorPeriodo / 360;
            SaldoInicial += interes;
            RegistrarTransaccion(interes, "Credito");
        }

        Console.WriteLine($"Se ha simulado el paso del tiempo. Saldo actual: {SaldoInicial}");
    }

    public void MantenimientoCuentasTercero()
    {
        while (true)
        {
            Console.WriteLine("\nMantenimiento de cuentas de terceros:");
            Console.WriteLine("1. Crear cuenta de tercero");
            Console.WriteLine("2. Eliminar cuenta de tercero");
            Console.WriteLine("3. Actualizar cuenta de tercero");
            Console.WriteLine("4. Salir");
            Console.Write("Seleccione una opción: ");
            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    CrearCuentaTercero();
                    break;
                case "2":
                    EliminarCuentaTercero();
                    break;
                case "3":
                    ActualizarCuentaTercero();
                    break;
                case "4":
                    return;
                default:
                    Console.WriteLine("Opción no válida.");
                    break;
            }
        }
    }

    private void CrearCuentaTercero()
    {
        CuentaTercero cuenta = new CuentaTercero
        {
            Id = contadorCuentasTercero++,
            Nombre = SolicitarDato("Nombre del cuentahabiente"),
            NumeroCuenta = SolicitarDato("Número de cuenta"),
            Banco = SolicitarDato("Nombre del banco"),
            Moneda = SolicitarMoneda()
        };

        cuentasTercero.Add(cuenta);
        Console.WriteLine("Cuenta de tercero creada exitosamente.");
    }

    private void EliminarCuentaTercero()
    {
        int id = SolicitarIdCuentaTercero();
        CuentaTercero cuenta = cuentasTercero.Find(c => c.Id == id);

        if (cuenta != null)
        {
            cuentasTercero.Remove(cuenta);
            Console.WriteLine("Cuenta de tercero eliminada exitosamente.");
        }
        else
        {
            Console.WriteLine("Cuenta de tercero no encontrada.");
        }
    }

    private void ActualizarCuentaTercero()
    {
        int id = SolicitarIdCuentaTercero();
        CuentaTercero cuenta = cuentasTercero.Find(c => c.Id == id);

        if (cuenta != null)
        {
            cuenta.Nombre = SolicitarDato("Nombre del cuentahabiente");
            cuenta.NumeroCuenta = SolicitarDato("Número de cuenta");
            cuenta.Banco = SolicitarDato("Nombre del banco");
            cuenta.Moneda = SolicitarMoneda();
            Console.WriteLine("Cuenta de tercero actualizada exitosamente.");
        }
        else
        {
            Console.WriteLine("Cuenta de tercero no encontrada.");
        }
    }

    private int SolicitarIdCuentaTercero()
    {
        Console.Write("Ingrese el ID de la cuenta de tercero: ");
        int.TryParse(Console.ReadLine(), out int id);
        return id;
    }

    private string SolicitarDato(string mensaje)
    {
        Console.Write($"{mensaje}: ");
        return Console.ReadLine();
    }

    private string SolicitarMoneda()
    {
        string moneda;
        do
        {
            Console.Write("Moneda (quetzales o dólares): ");
            moneda = Console.ReadLine().ToLower();
        } while (moneda != "quetzales" && moneda != "dólares");

        return moneda;
    }

    public void RealizarTransferencia()
    {
        Console.WriteLine("Cuentas disponibles:");
        foreach (var cuenta in cuentasTercero)
        {
            Console.WriteLine($"ID: {cuenta.Id}, Nombre: {cuenta.Nombre}, Banco: {cuenta.Banco}, Moneda: {cuenta.Moneda}");
        }

        int id = SolicitarIdCuentaTercero();
        CuentaTercero cuentaTercero = cuentasTercero.Find(c => c.Id == id);

        if (cuentaTercero == null)
        {
            Console.WriteLine("Cuenta de tercero no encontrada.");
            return;
        }

        Console.WriteLine("Ingrese el monto a transferir (200.00 o 2000.00): ");
        if (!decimal.TryParse(Console.ReadLine(), out decimal monto) || (monto != 200.00m && monto != 2000.00m))
        {
            Console.WriteLine("Monto no válido.");
            return;
        }

        if (SaldoInicial >= monto)
        {
            SaldoInicial -= monto;
            RegistrarTransaccion(monto, "Debito");
            Console.WriteLine($"Transferencia realizada exitosamente. Saldo actual: {SaldoInicial}");
        }
        else
        {
            Console.WriteLine("Saldo insuficiente.");
        }
    }

    public void PagoDeServicios()
    {
        Console.WriteLine("Proveedores de servicios:");
        Console.WriteLine("1. Empresa de agua");
        Console.WriteLine("2. Empresa Eléctrica");
        Console.WriteLine("3. Telefónica");
        Console.Write("Seleccione una opción: ");
        string opcion = Console.ReadLine();

        string proveedor = opcion switch
        {
            "1" => "Empresa de agua",
            "2" => "Empresa Eléctrica",
            "3" => "Telefónica",
            _ => null
        };

        if (proveedor == null)
        {
            Console.WriteLine("Opción no válida.");
            return;
        }

        Console.Write("Ingrese el monto del pago: ");
        if (!decimal.TryParse(Console.ReadLine(), out decimal monto))
        {
            Console.WriteLine("Monto no válido.");
            return;
        }

        if (SaldoInicial >= monto)
        {
            SaldoInicial -= monto;
            RegistrarTransaccion(monto, "Debito");
            Console.WriteLine($"Pago realizado exitosamente. Saldo actual: {SaldoInicial}");
        }
        else
        {
            Console.WriteLine("Saldo insuficiente.");
        }
    }

    public void ImprimirInformeTransacciones()
    {
        Console.WriteLine("Historial de transacciones:");
        foreach (var transaccion in transacciones)
        {
            Console.WriteLine($"{transaccion.Fecha} - {transaccion.Tipo} - {transaccion.Monto}");
        }
    }

    private string SolicitarDatoConLongitud(string mensaje, int longitud)
    {
        string dato;
        do
        {
            Console.Write($"{mensaje}: ");
            dato = Console.ReadLine();
            if (dato.Length != longitud)
            {
                Console.WriteLine($"El dato debe tener exactamente {longitud} caracteres.");
            }
        } while (dato.Length != longitud);

        return dato;
    }

    private decimal SolicitarDecimal(string mensaje)
    {
        decimal valor;
        do
        {
            Console.Write($"{mensaje}: ");
        } while (!decimal.TryParse(Console.ReadLine(), out valor));
        return valor;
    }

    private string SolicitarTipoCuenta()
    {
        string tipo;
        do
        {
            Console.WriteLine("Ingrese el tipo de cuenta (monetaria quetzales, ahorro quetzales, monetaria dólares, ahorro dólares):");
            tipo = Console.ReadLine().ToLower();
            if (tipo != "monetaria quetzales" && tipo != "ahorro quetzales" && tipo != "monetaria dólares" && tipo != "ahorro dólares")
            {
                Console.WriteLine("Tipo de cuenta no válido.");
            }
        } while (tipo != "monetaria quetzales" && tipo != "ahorro quetzales" && tipo != "monetaria dólares" && tipo != "ahorro dólares");

        return tipo;
    }
}

class Transaccion
{
    public DateTime Fecha { get; set; }
    public decimal Monto { get; set; }
    public string Tipo { get; set; }
}

class CuentaTercero
{
    public int Id { get; set; }
    public string Nombre { get; set; }
    public string NumeroCuenta { get; set; }
    public string Banco { get; set; }
    public string Moneda { get; set; }
}