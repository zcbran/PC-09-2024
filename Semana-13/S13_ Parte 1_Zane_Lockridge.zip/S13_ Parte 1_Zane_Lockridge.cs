﻿using System.Diagnostics.CodeAnalysis;

namespace semana13
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = new int[8]; 
            Console.Write("Ingresa lo que se te pide. ");
            for (int i = 0; i < 8; i++) 
            {
                Console.WriteLine("Ingresa numero " + i + ":");
                array[i]= int.Parse(Console.ReadLine());

            }
            int sum = 0;
            for (int i= 0; i < 8; i++)
            {
                sum = sum + array[i];
            }
            Console.WriteLine("Su resultado es: " + sum);

            int promedio = sum / 8;
            Console.WriteLine("Su promedio es: " + promedio);
            Console.ReadKey();
        }
    }
}

