﻿namespace parte2
{
    class program
    {
        static void Main(string[] args)
        {
            int[] array = new int[4];
            Console.WriteLine("Ingresa lo que se te pide: ");
            for (int i = 0; i < 4; i++) 
            {
                Console.WriteLine("ingresa tu nombre");
                
                //No lo pude terminar ;-;//
            
            }
            
            

            
        }
    }
}