﻿using Classes;

var account = new BankAccount("<name>", 900);
Console.WriteLine($"Account {account.Number} was created for {account.Owner} with {account.Balance} balance.");

account.MakeWithdrawal(550, DateTime.Now, "Rent payment");
Console.WriteLine(account.Balance);
account.MakeDeposit(110, DateTime.Now, "friend paid me back");
Console.WriteLine(account.Balance);

Console.WriteLine(account.GetAccountHistory());

// Test that the initial balances must be positive:
try
{
    var invalidAccount = new BankAccount("invalid", -44);
}
catch (ArgumentOutOfRangeException e)
{
    Console.WriteLine("Exception caught creating account with negative balance");
    Console.WriteLine(e.ToString());
}

// Test for a negative balance
try
{
    account.MakeWithdrawal(750, DateTime.Now, "Attempt to overdraw");
}
catch (InvalidOperationException e)
{
    Console.WriteLine("Exception caught trying to overdraw");
    Console.WriteLine(e.ToString());
}
try
{
    var invalidacc1 = new BankAccount("invalid", -44);
}
catch (ArgumentOutOfRangeException e)
{
    Console.WriteLine("The account balance must be positive.");
    Console.WriteLine(e.ToString());
}
try
{
    account.Makedeposit(1500, DateTime.Now, "Balance is to big for deposit");
}
catch
{
    Console.WriteLine("The balance you desire to deposit is too big to complete the action. Try depositing again with a lower balance.");
    Console.WriteLine(e.toString());
}